for num in range(1, 21):
    if num % 3 != 0:
        print(num)
