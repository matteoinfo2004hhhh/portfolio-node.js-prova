print("La tabellina del 1");
for i in range(1, 11):
    risultato = 1 * i
    print("1 x", i, "=", risultato)
print("La tabellina del 2");
for i in range(1, 11):
    risultato = 2 * i
    print("2 x", i, "=", risultato)
print("La tabellina del 3");
for i in range(1, 11):
    risultato = 3 * i
    print("3 x", i, "=", risultato)
print("La tabellina del 4");
for i in range(1, 11):
    risultato = 4 * i
    print("4 x", i, "=", risultato)
print("La tabellina del 5");
for i in range(1, 11):
    risultato = 5 * i
    print("5 x", i, "=", risultato)
print("La tabellina del 6");
for i in range(1, 11):
    risultato = 6 * i
    print("6 x", i, "=", risultato)
print("La tabellina del 7");
for i in range(1, 11):
    risultato = 7 * i
    print("7 x", i, "=", risultato)
print("La tabellina del 8");
for i in range(1, 11):
    risultato = 8 * i
    print("8 x", i, "=", risultato)
print("La tabellina del 9");
for i in range(1, 11):
    risultato = 9 * i
    print("9 x", i, "=", risultato)
print("La tabellina del 10");
for i in range(1, 11):
    risultato = 10 * i
    print("10 x", i, "=", risultato)