numeri = [int(x) for x in input("Inserisci una lista di numeri separati da spazi: ").split()]
min = min(numeri)
max = max(numeri)
print("Valore minimo nella lista:", min)
print("Valore massimo nella lista:", max)