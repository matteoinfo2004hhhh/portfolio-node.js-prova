for i in range(1, 11):
    risultato = 10 * i
    print("10 x", i, "=", risultato)