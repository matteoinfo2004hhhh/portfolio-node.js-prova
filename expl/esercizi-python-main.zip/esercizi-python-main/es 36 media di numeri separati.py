numeri = [int(x) for x in input("Inserisci una lista di numeri separati da spazi: ").split()]
media = sum(numeri ) / len(numeri )
print("Media della lista di numeri:", media )