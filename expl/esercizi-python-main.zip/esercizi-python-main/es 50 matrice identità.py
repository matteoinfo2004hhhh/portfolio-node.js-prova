matriceindentita = [[1 if i == j else 0 for j in range(5)] for i in range(5)]

for row in matriceindentita :
    print(row)
