print("ciao mondo")
