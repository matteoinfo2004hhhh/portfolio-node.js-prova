stringa = input("Inserisci una stringa: ")
stringaInversa = stringa[::-1]
print("La stringa al contrario è:", stringaInversa )