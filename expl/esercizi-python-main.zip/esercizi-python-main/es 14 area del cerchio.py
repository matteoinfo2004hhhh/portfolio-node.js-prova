import math

raggio = float(input("Inserisci il raggio del cerchio: "))
Areacerchio = math.pi * raggio ** 2
print("L'area del cerchio è:", Areacerchio)
