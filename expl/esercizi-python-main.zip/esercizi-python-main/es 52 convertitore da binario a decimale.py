numd = int(input("Inserisci un numero decimale: "))
numb = bin(numd).replace("0b", "")
print("Numero binario corrispondente:", numb)