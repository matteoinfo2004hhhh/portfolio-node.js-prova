totale = sum([num for num in range(1, 21) if num % 2 != 0])
print("Somma dei numeri dispari da 1 a 20:", totale)