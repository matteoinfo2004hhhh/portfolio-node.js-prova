print("il quadrato del cubo");
numero=int(input("numero"));
quadrato=numero*numero;
cubo=quadrato*numero;
print("Quadrato di "+str(numero)+" = " + str(quadrato))
print("Cubo di "+str(numero)+" = " + str(cubo))
