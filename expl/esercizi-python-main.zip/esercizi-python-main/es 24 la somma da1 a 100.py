somma = 0
for i in range(1, 101):
    somma += i
print("La somma dei numeri da 1 a 100 è:", somma)
