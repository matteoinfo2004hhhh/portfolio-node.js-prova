num = int(input("Inserisci un numero: "));
num2 = int(input("Inserisci un numero: "));
somma=0;
somma=num+num2;
print("Il doppio del numero inserito è:", somma);