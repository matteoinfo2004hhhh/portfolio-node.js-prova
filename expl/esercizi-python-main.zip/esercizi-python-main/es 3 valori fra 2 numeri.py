num = 5
num2 = 12
print("il numero vale",num);
print("il numero 2 vale ",num2);
