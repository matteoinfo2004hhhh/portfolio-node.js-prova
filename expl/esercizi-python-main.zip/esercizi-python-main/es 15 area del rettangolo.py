base = float(input("Inserisci la lunghezza della base: "));
altezza = float(input("Inserisci l'altezza: "));
Arearettangolo = base * altezza;
print("L'area del rettangolo è:", Arearettangolo);
