parola = input("Inserisci una parola: ")
inverti = parola[::-1]
print("Parola invertita:", inverti)
