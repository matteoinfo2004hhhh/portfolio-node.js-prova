num = int(input("Inserisci un numero: "));
num2 = int(input("Inserisci un numero2: "));
somma=0;
somma=num+num2;
print("La somma dei numeri è:", somma);