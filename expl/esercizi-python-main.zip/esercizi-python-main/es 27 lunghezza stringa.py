stringa = input("Inserisci una stringa: ")
lunghezza = len(stringa)
print("La lunghezza della stringa è:", lunghezza)
