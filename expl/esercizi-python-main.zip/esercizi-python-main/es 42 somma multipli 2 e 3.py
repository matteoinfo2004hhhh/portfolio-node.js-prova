totale = sum(num for num in range(1, 31) if num % 2 == 0 or num % 3 == 0);
print("Somma dei multipli di 2 o 3 da 1 a 30:", totale);
