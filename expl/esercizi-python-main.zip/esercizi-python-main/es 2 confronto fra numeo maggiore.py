if 10 > 2:
  print("il numero 10 è maggiore di 2");