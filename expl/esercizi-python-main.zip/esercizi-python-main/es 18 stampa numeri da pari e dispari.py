for i in range(1, 11):
    if i%2==0:
      print("pari",i)
    if i%2==1:
      print("dipari",i)

