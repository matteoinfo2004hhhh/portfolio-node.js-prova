numeri = list(range(2, 21, 2))
cubi = [num ** 3 for num in numeri]

print("Numeri pari:", numeri)
print("Cubi corrispondenti:", cubi)