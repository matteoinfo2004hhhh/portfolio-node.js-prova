for i in range(1, 11):
    risultato = 5 * i
    print("5 x", i, "=", risultato)