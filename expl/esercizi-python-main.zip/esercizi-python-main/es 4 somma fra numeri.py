num = 5;
num2 = 12;
somma=0;
somma=num+num2;
print("Il numero vale",num);
print("Il numero 2 vale ",num2);
print("La somma vale ",somma);