numeri = [int(x) for x in input("Inserisci una lista di numeri separati da spazi: ").split()]
totale = sum(numeri)
print("Somma degli elementi nella lista:", totale)

