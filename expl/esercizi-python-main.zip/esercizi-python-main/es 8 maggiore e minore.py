num = int(input("Inserisci un numero: "));
num2 = int(input("Inserisci un numero: "));
if num>num2:
  print("il primo numero:",num," è maggiore di numero2:",num2);
else:
  print("il secondo numero2:",num2," è maggiore di numero:",num);