num = float(input("Inserisci un numero: "))
if num > 0:
    print("Il numero è positivo.")
elif num < 0:
    print("Il numero è negativo.")
else:
    print("Il numero è zero.")
