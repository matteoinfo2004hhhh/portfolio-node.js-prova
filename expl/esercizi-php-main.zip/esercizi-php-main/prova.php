<HTML>
<BODY>
<H1>Pagina di prova</H1>

<?php
   $a=30;
   echo "<h2>Il numero mostrato è ".$a."</h2>";
   echo "<h2>Bis - Il numero mostrato è $a</h2>";
?>

   <h2>Ter - Il numero mostrato è <?php echo $a; ?></h2>

</BODY>
</HTML>
