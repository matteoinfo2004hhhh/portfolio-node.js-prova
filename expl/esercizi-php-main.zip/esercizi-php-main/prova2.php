<HTML>
<BODY>
<H1>Seconda pagina di prova</H1>

<?php

   $a=12;
   $b=41;

   echo "<br>";
   echo "<br>a+b : ".($a+$b);
   echo "<br>a.b : ".($a.$b);
   echo "<br>a+b : ($a+$b)";
   echo "<br>a.b : $a.$b";
   
   echo "<br>";
   $a2="12";
   $b2="41";
   echo "<br>a2+b2 : ".($a2+$b2);
   echo "<br>a2.b2 : ".($a2.$b2);
  
   echo "<br>";
   $a3="abc";
   $b3="123";
   //echo "<br>a3+b3 : ".($a3+$b3);
   echo "<br>a3.b3 : ".($a3.$b3);

   echo "<br>";
   $a4="a22";
   $b4="33b";
   echo "<br>a4+b4 : ".($a4+$b4);
   echo "<br>a4.b4 : ".($a4.$b4);
?>

</BODY>
</HTML>
