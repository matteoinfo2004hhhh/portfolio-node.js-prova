<HTML>
   <BODY>
      <FORM name='F1' method='post' action='secondo2.php'>
         <INPUT type='text' name='T1' size='5' />
         <INPUT type='submit' name='B1' value='esegui' />
      </FORM>
   </BODY>
</HTML>