<?php
   $a=7;
   $c="marco";
   $d=1;
   $b="<H".$d.">".$a."</H".$d.">";
?>

<HTML>
   <BODY>
      <H1>TITOLO</H1>

      <?php
         echo $a*2;
         echo $c;
         echo $b;
      ?>

   </BODY>
</HTML>