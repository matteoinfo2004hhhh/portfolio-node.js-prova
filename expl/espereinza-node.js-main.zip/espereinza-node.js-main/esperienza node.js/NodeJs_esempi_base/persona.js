const nome1="marco"
const nome2="giovanni"
const nome3="luca"
const nome4="elisa"

module.exports={nome1,nome2,nome3}