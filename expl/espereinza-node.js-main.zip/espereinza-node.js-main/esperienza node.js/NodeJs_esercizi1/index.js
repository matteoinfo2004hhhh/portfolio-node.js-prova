const eser=require('./esercizi.js');

d=eser.dispari(6);
e=eser.dispari(7);
console.log(d);
console.log(e);

f=eser.tabellina(5);
console.log(f);

g=eser.fibonacci(50);
console.log(g);

