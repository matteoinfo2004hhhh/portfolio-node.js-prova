var myGamePiece;
var sfondo;
//nemici
var nemici = [];
var nemici2 = [];
var nemici3 = [];
//compomenti del gioco
var myScore;
var myWrite;
var p=document.getElementById('pp');
var punto=0;
var musica;
var suono;
var suonog;
function dd(){
    var divDaNascondere2 = document.getElementById("jj");
    divDaNascondere2.style.display = "none";
}

function startGame() {
    myGamePiece = new component(200, 200, "mira.png", 900, 420, "image");
    myScore = new component("40px", "Consolas", "white", 6, 40, "text");
    myWrite = new component("100px", "Consolas", "red", 780,200, "text");
    sfondo = new component(1600, 960 ,"1.png ", 0 , 0 , "image");
    musica = new sound("m.mp3");
    suono = new sound("d.wav");
    suonog = new sound("gun.wav");
    myGameArea.start();
    var divDaNascondere = document.getElementById("mm");
    divDaNascondere.style.display = "none";
}

var myGameArea = {
    canvas : document.createElement("canvas"),
    start : function() {
        this.canvas.width = 1600;
        this.canvas.height = 960;
        this.context = this.canvas.getContext("2d");
        document.body.insertBefore(this.canvas, document.body.childNodes[0]);
        this.frameNo = 0;
        this.frameNo2= 0;
        this.frameNog = 0;
        this.frameNot = 0;
        this.frameNogameover = 0;
        this.interval = setInterval(updateGameArea, 20);
        window.addEventListener('mousedown', function (e) {
            myGameArea.x = e.pageX;
            myGameArea.y = e.pageY;
        });
        
        window.addEventListener('mouseup', function (e) {
            myGameArea.x = false;
            myGameArea.y = false;
            // Gestisci il rilascio del pulsante del mouse qui
        });
        
        window.addEventListener('mousemove', function (e) {
            if (myGameArea.x && myGameArea.y) {
                // Calcola la differenza tra le posizioni precedenti e attuali del mouse
                var deltaX = e.pageX - myGameArea.x;
                var deltaY = e.pageY - myGameArea.y;
            }
            myGameArea.x = e.pageX;
            myGameArea.y = e.pageY;
        });
    },
    clear : function(){
        this.context.clearRect(0, 0, this.canvas.width, this.canvas.height);
    }
}


function component(width, height, color, x, y, type) {
    this.type = type;
    if (type == "image") {
        this.image = new Image();
        this.image.src = color;
    }
    this.score = 0;
    this.width = width;
    this.height = height;
    this.speedX = 0;
    this.speedY = 0;    
    this.x = x;
    this.y = y;
    this.update = function() {
        ctx = myGameArea.context;
        if (this.type == "text") {
            ctx.font = this.width + " " + this.height;
            ctx.fillStyle = color;
            ctx.fillText(this.text, this.x, this.y);
        } else {
            ctx.fillStyle = color;
           
        }
        if (type == "image") {
            ctx.drawImage(this.image, 
                this.x, 
                this.y,
                this.width, this.height);
        } else {
            ctx.fillStyle = color;
   
        }
    }
    this.newPos = function() {
        this.x += this.speedX;
        this.y += this.speedY;  
    }
    
    
    this.crashWith = function(otherobj) {
        var myleft = this.x;
        var myright = this.x + (this.width);
        var mytop = this.y;
        var mybottom = this.y + (this.height);
        var otherleft = otherobj.x;
        var otherright = otherobj.x + (otherobj.width);
        var othertop = otherobj.y;
        var otherbottom = otherobj.y + (otherobj.height);
        var crash = true;
        if ((mybottom < othertop) || (mytop > otherbottom) || (myright < otherleft) || (myleft > otherright)) {
            crash = false;
        }
        return crash;
    }

    this.clicked = function() {
        var myleft = this.x;
        var myright = this.x + (this.width);
        var mytop = this.y;
        var mybottom = this.y + (this.height);
        var clicked = true;
        if ((mybottom < myGameArea.y) || (mytop > myGameArea.y) || (myright < myGameArea.x) || (myleft > myGameArea.x)) {
            clicked = false;
        }
        return clicked;
    }
}


function updateGameArea() {

    myGameArea.clear();
    myGameArea.frameNo += 1;
    myGamePiece.speedX = 0;
    myGamePiece.speedY = 0;   
    sfondo.newPos();
    sfondo.update();
    musica.play();

    if (myGameArea.x && myGameArea.y) {
        myGamePiece.x = myGameArea.x;
        myGamePiece.y = myGameArea.y;        
    }

   if(myGamePiece.clicked()){
   suonog.play();
   }
    
    //generazione nemici
    if(myGameArea.frameNo>10){
        if (myGameArea.frameNo == 1 || everyinterval(190)) {
            x = myGameArea.canvas.width -1;
            y = myGameArea.canvas.height - 200;
            nemici.push(new component(60, 60, "g1.png", x, y, "image"));
        }
    }
  
    if(myGameArea.frameNo>400){
        if (myGameArea.frameNo == 1 || everyinterval(210)) {
            x = myGameArea.canvas.width -1;
            y = myGameArea.canvas.height - 200;
            nemici2.push(new component(60, 60, "g3.png", x, y, "image"));
        }
    }

      
    if(myGameArea.frameNo>800){
        if (myGameArea.frameNo == 1 || everyinterval(30)) {
            x = myGameArea.canvas.width -1;
            y = myGameArea.canvas.height - 200;
            nemici3.push(new component(60, 60, "g3.png", x, y, "image"));
        }
    }
    //cicli nemici
    for(i=0;i<nemici.length; i += 1){
        numf=Math.floor(Math.random()*2)+1;
      
        if(numf==1){
            nemici[i].image.src ="g1.png";
        }
        if(numf==2){
            nemici[i].image.src ="g2.png";
        }
        nemici[i].x-=2;  
        nemici[i].update();    
        if(nemici[i].x<-200){
            myWrite.update();
            myGameArea.stop();
        }
        if(nemici[i].clicked()){
            myGameArea.frameNo2+=200;
            punto+=200;  
            suono.play();
            nemici.splice(i,1);
            i--;
        }
    }  

    for(i=0;i<nemici2.length; i += 1){
        numf=Math.floor(Math.random()*2)+1;
      
        if(numf==1){
            nemici2[i].image.src ="g3.png";
        }
        if(numf==2){
            nemici2[i].image.src ="g4.png";
        }
        nemici2[i].x-=6;  
        nemici2[i].update();    
        if(nemici2[i].x<-200){
            myWrite.update();
            myGameArea.stop();
        }
        if(nemici2[i].clicked()){
            myGameArea.frameNo2+=200;
            punto+=200;  
            suono.play();
            nemici2.splice(i,1);
            i--;
        }
    }  
   
    for(i=0;i<nemici3.length; i += 1){
        numf=Math.floor(Math.random()*2)+1;
      
        if(numf==1){
            nemici3[i].image.src ="g1.png";
        }
        if(numf==2){
            nemici3[i].image.src ="g2.png";
        }
        nemici3[i].x-=3;  
        nemici3[i].update();    
        if(nemici3[i].x<-200){
            myWrite.update();
            myGameArea.stop();
        }
        if(nemici3[i].clicked()){
            myGameArea.frameNo2+=200;
            punto+=200;  
            suono.play();
            nemici3.splice(i,1);
            i--;
        }
    }  

    var elemento = document.getElementById('pp');
    var nuovoValore = punto;
    elemento.textContent = nuovoValore;
   
    myScore.text="PUNTEGGIO:" + myGameArea.frameNo2+"";
    myScore.update();
    myWrite.text="GAME OVER";

    myGamePiece.newPos();
    myGamePiece.update();


}

function sound(src) {
    this.sound = document.createElement("audio");
    this.sound.src = src;
    this.sound.setAttribute("preload", "auto");
    this.sound.setAttribute("controls", "none");
    this.sound.style.display = "none";
    document.body.appendChild(this.sound);
    this.play = function(){
        this.sound.play();
    }
    this.stop = function(){
        this.sound.pause();
      
    }    
}


function everyinterval(n) {
    if ((myGameArea.frameNo / n) % 1 == 0) {return true;}
    return false;

}

