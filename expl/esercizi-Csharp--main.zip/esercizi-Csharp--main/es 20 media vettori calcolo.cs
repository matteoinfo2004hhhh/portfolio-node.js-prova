decimal[] vettore = { 1.5m, 2.5m, 3.5m, 4.5m, 5.5m };
decimal somma = 0;

foreach (decimal numero in vettore)
{
    somma += numero;
}

decimal media = somma / vettore.Length;
Console.WriteLine("Media: " + media);
