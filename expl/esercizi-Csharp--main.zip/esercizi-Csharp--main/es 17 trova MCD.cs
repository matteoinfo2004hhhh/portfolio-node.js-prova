using System;

class Program{
    static void Main(){
        
        Console.WriteLine("Inserisci il primo numero: ");
        int num1 = Convert.ToInt32(Console.ReadLine());

        Console.WriteLine("Inserisci il secondo numero: ");
        int num2 = Convert.ToInt32(Console.ReadLine());

        int mcd = 1;
        for (int i = 1; i <= num1 && i <= num2; i++){
            if (num1 % i == 0 && num2 % i == 0){
                mcd = i;
            }
        }

        Console.WriteLine($"Il Massimo Comun Divisore e:"+mcd);
    }
}