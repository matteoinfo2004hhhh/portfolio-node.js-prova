using System;
using System.Linq;

class Program{
    static void Main(){
        
        Console.WriteLine("Inserisci la prima stringa: ");
        string stringa1 = Console.ReadLine().ToLower();

        Console.WriteLine("Inserisci la seconda stringa: ");
        string stringa2 = Console.ReadLine().ToLower();

        bool isAnagramma = stringa1.Length == stringa2.Length && stringa1.OrderBy(c => c).SequenceEqual(stringa2.OrderBy(c => c));

        if (isAnagramma){
            Console.WriteLine("Le stringhe sono anagrammi.");
        }else{
            Console.WriteLine("Le stringhe non sono anagrammi.");
        }
    }
}