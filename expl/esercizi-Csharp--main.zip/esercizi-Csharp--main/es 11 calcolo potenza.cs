using System;

class Program{
    static void Main(){
        
        Console.WriteLine("Inserisci la base: ");
        double baseNum = Convert.ToDouble(Console.ReadLine());

        Console.WriteLine("Inserisci l'esponente: ");
        double esponente = Convert.ToDouble(Console.ReadLine());

        double risultato = Math.Pow(baseNum, esponente);
        
        Console.WriteLine($"Il risultato e: "+risultato);
    }
}