using System;

class Program{
    static void Main(){
        
        Console.WriteLine("Inserisci un numero: ");
        int num = Convert.ToInt32(Console.ReadLine());

        bool isPrimo = true;

        for (int i = 2; i <= num / 2; i++){
            if (num % i == 0){
                isPrimo = false;
                break;
            }
        }

        if (isPrimo){
            Console.WriteLine("Il numero e primo.");
        }else{
            Console.WriteLine("Il numero non e primo.");
        }
    }
}