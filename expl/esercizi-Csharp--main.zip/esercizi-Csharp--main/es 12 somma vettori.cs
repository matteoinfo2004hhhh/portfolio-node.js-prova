
using System;

int[] vettore1 = { 3, 2, 3 };
int[] vettore2 = { 4, 5, 6 };
int[] somma = new int[3];

for (int i = 0; i < 3; i++){
    somma[i] = vettore1[i] + vettore2[i];
    Console.WriteLine(somma[i]);
}