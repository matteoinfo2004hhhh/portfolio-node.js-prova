using System;

class Program{
    static void Main(){
        
        Console.WriteLine("Inserisci una sequenza di numeri separati da spazi: ");
        string[] numeri = Console.ReadLine().Split(' ');

        double somma = 0;
        int conteggio = 0;

        foreach (string numero in numeri){
            if (double.TryParse(numero, out double num)){
                somma += num;
                conteggio++;
            }
        }

        if (conteggio > 0){
            double media = somma / conteggio;
            Console.WriteLine($"La media dei numeri inseriti e "+media);
        }else{
            Console.WriteLine("Nessun numero valido inserito.");
        }
        
    }
}