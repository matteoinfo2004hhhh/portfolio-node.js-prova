using System;

class Program{
    static void Main(){
        
        Console.WriteLine("Inserisci il numero di numeri primi da generare: ");
        int n = Convert.ToInt32(Console.ReadLine());
        int count = 0;
        int num = 2;
        

        Console.WriteLine($"I primi "+n+" numeri primi sono: ");
        while (count < n){
            bool isPrime = true;
            for (int i = 2; i <= Math.Sqrt(num); i++){
                if (num % i == 0){
                    isPrime = false;
                    break;
                }
            }

            if (isPrime){
                Console.Write(num + " ");
                count++;
            }

            num++;
        }
    }
}