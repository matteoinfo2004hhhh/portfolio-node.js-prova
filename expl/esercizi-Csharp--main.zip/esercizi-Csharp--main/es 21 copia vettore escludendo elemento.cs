using System;

int[] vettoreOriginale = { 1, 2, 3, 4, 5 };
int elementoDaEscludere = 3;
int[] vettoreCopia = new int[vettoreOriginale.Length - 1];
int j = 0;

for (int i = 0; i < vettoreOriginale.Length; i++){
    if (vettoreOriginale[i] != elementoDaEscludere){
        vettoreCopia[j] = vettoreOriginale[i];
        j++;
    }
}

foreach (int numero in vettoreCopia){
    Console.WriteLine(numero);
}