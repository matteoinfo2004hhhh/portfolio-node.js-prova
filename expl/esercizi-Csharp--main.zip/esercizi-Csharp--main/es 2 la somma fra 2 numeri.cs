using System;

class Program{
    static void Main(){
        Console.WriteLine("Inserisci il primo numero: ");
        int num1 = Convert.ToInt32(Console.ReadLine());

        Console.WriteLine("Inserisci il secondo numero: ");
        int num2 = Convert.ToInt32(Console.ReadLine());

        int somma = num1 + num2;
        Console.WriteLine($"La somma :"+somma);
    }
}
