using System;
class Program{
    
    static void Main(){
        Console.WriteLine("Inserisci un numero: ");
        int num = Convert.ToInt32(Console.ReadLine());

        if (num % 2 == 0){
            Console.WriteLine("Il numero e pari.");
        }else{
            Console.WriteLine("Il numero e dispari.");
        }
        
    }
}