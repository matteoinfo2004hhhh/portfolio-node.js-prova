using System;

class Program{
    static void Main(){

        Console.WriteLine("Inserisci una parola: ");
        string parola = Console.ReadLine().ToLower();

        bool isPalindromo = true;
        for (int i = 0; i < parola.Length / 2; i++){
            if (parola[i] != parola[parola.Length - i - 1]){
                isPalindromo = false;
                break;
            }
        }

        if (isPalindromo){
            Console.WriteLine("La parola è un palindromo.");
        }else{
            Console.WriteLine("La parola non è un palindromo.");
        }
        
    }
}
