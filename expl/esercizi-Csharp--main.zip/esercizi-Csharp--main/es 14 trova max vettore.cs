
using System;

int[] vettore = { 10, 2, 8, 4, 5 };
int max = vettore[0];

foreach (int numero in vettore)
{
    if (numero > max)
    {
        max = numero;
    }
}
Console.WriteLine("Massimo: " + max);