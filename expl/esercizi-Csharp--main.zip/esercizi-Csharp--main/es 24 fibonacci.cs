using System;

class Program{
    static void Main(){

        Console.WriteLine("Inserisci il numero di numeri di Fibonacci da generare: ");
        int n = Convert.ToInt32(Console.ReadLine());

        int primoNumero = 0, secondoNumero = 1, prossimoNumero;
        Console.Write($"I primi {n} numeri di Fibonacci sono: {primoNumero} {secondoNumero}");

        for (int i = 3; i <= n; i++){
            prossimoNumero = primoNumero + secondoNumero;
            Console.Write($" {prossimoNumero}");
            primoNumero = secondoNumero;
            secondoNumero = prossimoNumero;
        }

        Console.WriteLine();
    }
}
