using System;

class Program{
    static void Main(){
        
        int[] array = { 1, 3, 5, 7, 9, 11, 13, 15 };
        Console.WriteLine("Inserisci un numero da cercare: ");
        int numeroDaCercare = Convert.ToInt32(Console.ReadLine());

        int inizio = 0;
        int fine = array.Length - 1;
        bool trovato = false;

        while (inizio <= fine){
            int centro = (inizio + fine) / 2;
            if (array[centro] == numeroDaCercare){
                trovato = true;
                break;
            }else if (array[centro] < numeroDaCercare){
                inizio = centro + 1;
            }else{
                fine = centro - 1;
            }
        }

        if (trovato){
            Console.WriteLine("Il numero è presente nell'array.");
        }else{
            Console.WriteLine("Il numero non è presente nell'array.");
        }
    }
}