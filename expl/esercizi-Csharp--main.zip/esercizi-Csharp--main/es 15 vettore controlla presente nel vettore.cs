
using System;

int[] vettore = { 1, 2, 3, 4, 5 };
int elementoDaCercare = 3;
bool presente = false;

foreach (int numero in vettore){
    if (numero == elementoDaCercare){
        presente = true;
        break;
    }
}

Console.WriteLine("Elemento presente: " + presente);
