using UnityEngine;
using UnityEngine.SceneManagement;

public class collisione : MonoBehaviour
D{
    void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.CompareTag("nemico 1")) {
        SceneManager.LoadScene("game over");
        }
  
    }
}