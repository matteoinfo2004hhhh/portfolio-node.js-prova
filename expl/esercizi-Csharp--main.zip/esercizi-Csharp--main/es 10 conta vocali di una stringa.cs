using System;

class Program{
    static void Main(){
        
        Console.WriteLine("Inserisci una stringa: ");
        string input = Console.ReadLine().ToLower();

        int conteggioVocali = 0;
        
        foreach (char carattere in input){
            if ("aeiou".Contains(carattere)){
                conteggioVocali++;
            }
        }

        Console.WriteLine($"Il numero di vocali nella stringa "+conteggioVocali);
    }
}