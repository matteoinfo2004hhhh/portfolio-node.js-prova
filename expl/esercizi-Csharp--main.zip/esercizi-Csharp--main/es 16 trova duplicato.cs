
int[] vettore = { 1, 2, 2, 3, 4, 4, 5 };
var duplicati = vettore.GroupBy(x => x).Where(x => x.Count() > 1).Select(x => x.Key);

foreach (int duplicato in duplicati){
    Console.WriteLine("Duplicato: " + duplicato);
}
