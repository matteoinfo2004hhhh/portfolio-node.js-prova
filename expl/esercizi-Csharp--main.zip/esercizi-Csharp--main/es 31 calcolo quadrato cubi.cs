using System;

class Program{
    static void Main(){
        
        Console.WriteLine("Inserisci un numero: ");
        double numero = Convert.ToDouble(Console.ReadLine());

        double quadrato = Math.Pow(numero, 2);
        double cubo = Math.Pow(numero, 3);

        Console.WriteLine($"Il quadrato del numero e:"+quadrato);
        Console.WriteLine($"Il cubo del numero e:"+cubo);
    }
}

