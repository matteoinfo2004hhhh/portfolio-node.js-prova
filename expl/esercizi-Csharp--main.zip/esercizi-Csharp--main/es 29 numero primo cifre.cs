using System;

class Program{
    static void Main(){
        
        Console.WriteLine("Inserisci un numero: ");
        int numero = Convert.ToInt32(Console.ReadLine());

        int prossimoNumeroPrimo = numero + 1;
        while (true){
            bool isPrimo = true;
            for (int i = 2; i <= Math.Sqrt(prossimoNumeroPrimo); i++){
                if (prossimoNumeroPrimo % i == 0){
                    isPrimo = false;
                    break;
                }
            }

            if (isPrimo){
                Console.WriteLine($"Il prossimo numero primo è: {prossimoNumeroPrimo}");
                break;
            }

            prossimoNumeroPrimo++;
        }
    }
}
