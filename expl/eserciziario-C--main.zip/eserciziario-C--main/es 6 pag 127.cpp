#include<iostream>
#include<math.h>
using namespace std;
int main (){
int num,dispari,pari,doppio;
cin>>num;
doppio=num*num;
if(num%2==1)
cout<<"numero dispari "<<endl;
else{
cout<<"numero pari ";
}
cout<<"numero doppio "<<doppio;
}

