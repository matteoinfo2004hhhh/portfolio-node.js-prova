#include<iostream>
using namespace std;
int main (){
int i,N,num,contaP=0;
for(i=0;i<0;i++);
  do{
  cout<<"dimmi il numero";
  cin>>num;
  contaP=i++;
  }while(num%2==1);
  cout<<"quanti numeri pari sono stati inseriti in precedenza"<<contaP;	
}	
	
	
	
	
