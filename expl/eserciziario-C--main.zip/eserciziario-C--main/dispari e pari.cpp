#include<iostream>
#include<math.h>
using namespace std;
int main(){
int numero,pari,dispari;
cout<<"dimmi il numero";
cin>>numero;
if(numero%2==0){
cout<<"il numero e pari";}
else {
cout<<"il numero e dispari";
}
}

