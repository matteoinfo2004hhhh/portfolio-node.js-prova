#include<math.h>
#include<iostream>
using namespace std;
int main (){
int num,radicequadrata;
cin>>num;
radicequadrata=sqrt(num);
cout<<"la radice del numero "<<radicequadrata;

}


