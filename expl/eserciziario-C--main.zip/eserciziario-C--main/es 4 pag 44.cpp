#include<iostream>
#include<math.h>
using namespace std;
int main(){
int n1,n2,n3;
cout<<"dammi il primo numero";
cin>>n1;
cout<<"dammi il secondo numero";
cin>>n2;
cout<<"dammi il terzo numero";
cin>>n3;
if(n1==n2 && n1==n3){
       cout<<"numeri sono uguali";
}
else{
	if(n1==n2 || n1==n3 || n1==n3){
cout<<"2 numeri sono uguali";}
else
cout<<"i numeri sono diversi";}
}	

