#include<iostream>
using namespace std;
int main(){
int dd,num,num2;
const int SOMMA=0;
const int SOTRAZIONE=2;
const int MOLTIPLICAZIONE=3;
const int DIVISIONE=4;
cout<<"dimmi il numero ";
cin>>num;
cout<<"dimmi il numero ";
cin>>num2;
cin>>dd;
switch(dd)
{
case SOMMA:
cout<<"somma"<<endl;
num+num2;
break;
case SOTRAZIONE:
cout<<"sotrazione"<<endl;
num-num2;
break;
case MOLTIPLICAZIONE:
cout<<""<<endl;
num*num2;
break;
case DIVISIONE:
cout<<""<<endl;
num/num2;
if(num2==0){
	if else
	cout<<"imposibile";
    if(num==0){
    else
    cout<<"indeterminato"
	}
}
break;
default:
cout<<"errata"<<endl;
}}

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
