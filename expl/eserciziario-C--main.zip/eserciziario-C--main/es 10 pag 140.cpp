#include<iostream>
using namespace std;
int main(){
int num;
const int NANO=7;
const int BIANCANEVE=7;
cin>>num;
switch(num)
{
case NANO:
cout<<" nano1"<<endl;
break;
case NANO:
cout<<" nano2"<<endl;
break;
case NANO:
cout<<"nano 3"<<endl;
break;
cout<<" nano4"<<endl;
break;
case NANO:
cout<<" nano5"<<endl;
break;
case NANO:
cout<<" nano6"<<endl;
break;
case NANO:
cout<<" nano2"<<endl;
break;
default:
cout<<""
;
}}
	
	
	
