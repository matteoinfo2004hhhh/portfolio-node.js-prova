#include<iostream>
#include<math.h>
using namespace std;
int main(){
int n1,n2,divisione;
cout<<"dammi il primo numero";
cin>>n1;
cout<<"dammi il secondo numero";
cin>>n2;
divisione=n1/n2;
if(divisione==0){
cout<<"divisione dei 2 numeri il denominatore e uguale a 0";}
else{
cout<<"divisione dei 2 numeri il denominatore non e 0";}     
}
