#include<math.h>
#include<iostream>
using namespace std;

int main(){

float saldo,dollari,bath,euro;
cout<<"il mio conto e:  ";
cin>>saldo;
dollari=saldo*1.07;
bath=saldo*39.02;
cout<<"il valore in dollari"<<dollari;
cout<<dollari;
cout<<"il valore in bath e";
cout<<bath;
}
   
		  
   
   
