#include<iostream>
#include<math.h>
using namespace std;
int main(){
float numero,seno,coseno;
cout<<"dammi il valore di un numero";
cin>>numero;
seno=sin(numero);
cout<<"il seno del numero"<<seno;
coseno=cos(numero);
cout<<"il coseno del numero"<<coseno;
}
