#include<iostream>
#include<math.h>
using namespace std;
int main(){
int n1,italiano,francese,inglese;
cout<<"dimmi un numero da comunicare";
cin>>n1;
if(n1==2){
cout<<"ciao";}
if(n1==4){
cout<<"hello";}
if(n1==5){
cout<<"Bonjour";}
}
