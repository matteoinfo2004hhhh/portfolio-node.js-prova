#include<iostream>
#include<math.h>
using namespace std;
int main(){
int numero,numero2,numero3,somma;
cout<<"dammi un numero ";
cin>>numero;
cout<<"dammi un secondo numero ";
cin>>numero2;
cout<<"dammi un terzo numero ";
cin>>numero3;
somma=numero+numero2+numero3;
cout<<"somma totale dei numeri "<<somma;
if(numero%2==1){
cout<<numero<<endl;}
if(numero2%2==1){
cout<<numero2<<endl;}
if(numero3%2==1){
cout<<numero3<<endl;}
}

