#include<iostream>
using namespace std;
int main () {
int num;
   do{
cout<<"dimmi un numero  ";
cin>>num;
if(num==0){
cout<<"il numero e nullo  ";}
else{
cout<<"";}
if(num%2==0){
cout<<"il numero e pari  ";}
else{
cout<<"";}

if(num%4==0){
cout<<"il numero e divisibile per 4  ";}
else{
cout<<" ";}

	        if(num%2==1){
            cout<<"il numero e dispari  ";}
            else{
            cout<<" ";}
	        
	                                           
	                if(num%7==0){
                    cout<<"il numero e divisibile per 7  ";}
                    else{
                    cout<<" ";}

}while(num!=17);
cout<<"numero porta male  "<<endl;
}
																		   
																		   
																		   
																		                    
	          
	                  




