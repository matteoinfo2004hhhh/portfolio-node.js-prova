#include<iostream>
#include<math.h>
using namespace std;
int main (){
int temperatura;
cin>>temperatura;
if(temperatura<18 and temperatura>5){
cout<<"hanno danni ireparabili";}
else{
}
cout<<"la situazione e pericolosa";
}


