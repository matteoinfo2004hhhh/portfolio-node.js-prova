#include<iostream>
#include<math.h>
using namespace std;
int main(){
int numero,logaritmo;
cout<<"dimmi il numero";
cin>>numero;
logaritmo=log10(numero);
cout<<"il logaritmio"<<logaritmo;

}
