#include<iostream>
#include<math.h>
using namespace std;
int main() {
int conp=0,conn=0;
int n1,n2,n3,n4,n5,i;
cout<<"metti un numero ";
cin>>n1;
cout<<"metti un secondo numero ";
cin>>n2;
cout<<"metti un terzo numero ";
cin>>n3;
cout<<"metti un quarto numero ";
cin>>n4;
cout<<"metti un quinto numero ";
cin>>n5;
for(i=0;i<10;i++)

{
i+1;
if(n1>0)
if(n2>0)
if(n3>0)
if(n4>0)
if(n5>0)
conp+=1;
else
conn+=1;
cout<<"numeri positivi  "<<conp;
cout<<"numeri negativi  "<<conn;
		
}}




	


