#include<iostream>
using namespace std;
int main(){
int voto;
cin>>voto;
cout<<"dammi il voto  ";
if(voto>=6){
cout<<"sufficiente";}
else{if(voto>=4){
cout<<"insufficiente";}
else{
cout<<"grave insufficiente";}	
}}
