#include<iostream>
#include<math.h>
using namespace std;
int main (){
int area,base,base2,altezza;
cin>>base;
cin>>base2;
cin>>altezza;
area=base+base2*altezza/2;
cout<<"area del trapezio e "<<area;
}
