#include<iostream>
#include<fstream>
using namespace std;

int main(){
int i;	
ofstream mioFile;

mioFile.open("nomi.txt");

for(i=0;i<mioFile;i++){
	
if(mioFile='A'){
mioFile<<endl;	
}	

}

mioFile.close();	
}
