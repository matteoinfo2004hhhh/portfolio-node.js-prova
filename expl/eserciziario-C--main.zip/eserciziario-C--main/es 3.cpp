#include<iostream>
using namespace std;
int main(){
float sconto1=10,sconto2=5,N,i,prezzo1,prezzo2,spesa,euro1=100,euro2=150;
cout<<"dimmi il numero dei prodotti"<<endl;
cin>>N;
for(i=0;i<N;i++){
 do{
cout<<"dimmi la spesa dei prodotti";
cin>>spesa;
if(spesa>euro1);
prezzo1=spesa/100+(sconto1/euro1*spesa);
}while(spesa>euro2);
prezzo2=spesa/150+(sconto2/euro2*spesa);
}
cout<<"il prezzo 1 totale  dello sconto 10% e  "<<prezzo1;
cout<<"il prezzo  2 totale dello sconto 5%  e  "<<prezzo2;
}

	
	
	
	
	
	
	
	
	
	
	
	
	
	


