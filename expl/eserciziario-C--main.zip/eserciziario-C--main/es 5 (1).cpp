#include<iostream>
using namespace std;
int main (){
int N,i,min=0,NP;
cout<<"dimmi il numero";
cin>>N;
for(i=0;i<N;i++){
do{	
cout<<"dammi un numero positivo";
cin>>NP;
}while(NP>0);{
cout<<"quale il valore minimo "<<min;}
}}

	


	
	
	
	
	
	
