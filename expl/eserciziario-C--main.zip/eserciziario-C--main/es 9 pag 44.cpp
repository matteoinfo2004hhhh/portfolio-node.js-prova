#include<iostream>
#include<math.h>
using namespace std;
int main(){
int n1,radicequadrata;
cout<<"dimmi il mio numero";
cin>>n1;
if(radicequadrata=sqrt(n1))
cout<<"radice quadrata"<<radicequadrata;
else{
cout<<"erore"<<radicequadrata;
}}



