#include<iostream>
#include<math.h>
using namespace std;
int main(){
int num1,num2,num3,num4,num5,positivi,negativo,somma=0;
cout<<"dimmi il primo valore del numero1 ";
cin>>num1;
cout<<"dimmi il primo valore del numero2 ";
cin>>num2;
cout<<"dimmi il primo valore del numero3 ";
cin>>num3;
cout<<"dimmi il primo valore del numero4 ";
cin>>num4;
cout<<"dimmi il primo valore del numero5 ";
cin>>num5;	
somma=num1+num2+num3+num4+num5;
if(num1%2==1){
cout<<num1<<endl;}
cout<<"numero1 e dispari ";
if(num2%2==1){
cout<<num2<<endl;}
cout<<"numero2 e dispari ";
if(num3%2==1){
cout<<num3<<endl;}
cout<<"numero3 e dispari ";
if(num4%2==1){
cout<<num4<<endl;}
cout<<"numero4 e dispari ";
if(num5%2==1){
cout<<num5<<endl;}
cout<<"numero5 e dispari ";

if(num1%3==1){
cout<<num1<<endl;}
cout<<"numero1 e pari ";
if(num2%3==1){
cout<<num2<<endl;}
cout<<"numero2 e pari ";
if(num3%3==1){
cout<<num3<<endl;}
cout<<"numero3 e pari ";
if(num4%3==1){
cout<<num4<<endl;}
cout<<"numero4 e pari ";
if(num5%3==1){
cout<<num5<<endl;}	
cout<<"numero5 e pari ";
}
