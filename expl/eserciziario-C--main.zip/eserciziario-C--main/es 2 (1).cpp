#include<iostream>
using namespace std;
int main () {
int num,somma=0,i;
for(i=0;i<10;i++){
if(num!=0){
cout<<"dimmi il numero";
cin>>num;
somma=somma+num;
}
}
cout<<"la somma e "<<somma;
}
	
	
	
