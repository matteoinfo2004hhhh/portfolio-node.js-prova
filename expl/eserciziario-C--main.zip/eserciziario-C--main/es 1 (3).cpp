#include<iostream>
using namespace std;
int main () {
int num,i;
do{
cout<<"dimmi il numero";
cin>>num;
if(num>10 and num<20){
i=i+1;
}
}while(i<3);
cout<<"estremi compresi"<<endl;
}


