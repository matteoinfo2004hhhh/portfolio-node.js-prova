#include<iostream>
using namespace std;
int main ()
{
int eta;
cin>>eta;
if(eta>10){
cout<<"il bignietto e gratis"<<endl;
}
if(eta>18){
cout<<"il bignietto costa 10 euro"<<endl;
}
if(eta>65){
cout<<"il bignietto costa 5 euro"<<endl;
}}

