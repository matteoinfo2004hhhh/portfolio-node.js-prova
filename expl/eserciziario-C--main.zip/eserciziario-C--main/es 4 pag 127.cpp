#include<iostream>
#include<math.h>
using namespace std;
int main (){
float sconto,euro,importoscontato,prezzo;
cin>>euro;
cin>>prezzo;
sconto=euro/20;
if(sconto>100){
importoscontato=prezzo*100;
cout<<"sconto totale importo della spessa";}
else{
cout<<"sconto non e totale importo della spessa";	
}}
