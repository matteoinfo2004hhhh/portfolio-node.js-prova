#include<iostream>
#include<math.h>
using namespace std;
int main(){
int numero,numero2,numero3,dispari;
cout<<"verifica che i numero siano dispari";
cin>>numero;
cout<<"verifica che i numero2 siano dispari";
cin>>numero2;
cout<<"verifica che i numero3 siano dispari";
cin>>numero3;
if(numero%2==1){
cout<<numero<<endl;}
if(numero2%2==1){
cout<<numero2<<endl;}
if(numero3%2==1){
cout<<numero3<<endl;}
}



