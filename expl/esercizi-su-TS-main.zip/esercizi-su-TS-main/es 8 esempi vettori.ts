let numeri: number[] = [1, 2, 3, 4, 5];
let parole: string[] = ["ciao", "mondo", "typescript"];
let vuoto: any[] = [];
numeri[0] = 10;
console.log(numeri[0]); 
console.log(numeri.length);
console.log(parole[2]);