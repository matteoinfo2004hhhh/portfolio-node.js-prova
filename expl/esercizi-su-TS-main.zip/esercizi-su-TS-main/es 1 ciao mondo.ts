let el = document.querySelector('#header')
let msg: string = 'ciao mondo'
el.innerHTML = msg
console.log("mostra tipo questo")