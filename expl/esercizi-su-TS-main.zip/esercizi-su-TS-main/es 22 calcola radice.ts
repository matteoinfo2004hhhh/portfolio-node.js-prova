function calcolaRadice(numero: number): number {
    return Math.sqrt(numero);
}

const numero = 16;
const risultatoRadice = calcolaRadice(numero);
console.log(`La radice quadrata di ${numero} è ${risultatoRadice}`);
