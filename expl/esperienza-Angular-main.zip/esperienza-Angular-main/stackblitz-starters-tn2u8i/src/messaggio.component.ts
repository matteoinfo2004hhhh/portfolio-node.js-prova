import { Component } from '@angular/core';

@Component({
  selector: 'app-messaggio',
  template: '<p>Benvenuto nell\'applicazione Angular!</p>',
})
export class MessaggioComponent { }
