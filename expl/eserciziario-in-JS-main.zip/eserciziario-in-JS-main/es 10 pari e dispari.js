const numero = 9;
if (numero % 2 === 0) {
    console.log(numero + " è un numero pari.");
} else {
    console.log(numero + " è un numero dispari.");
}
