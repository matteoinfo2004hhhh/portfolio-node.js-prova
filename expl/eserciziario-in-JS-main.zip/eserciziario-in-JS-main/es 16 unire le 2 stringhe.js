const primaStringa = "Buongiorno, ";
const secondaStringa = "mondo!";
const stringaUnita = primaStringa + secondaStringa;
console.log("Le due stringhe unite sono: " + stringaUnita);
