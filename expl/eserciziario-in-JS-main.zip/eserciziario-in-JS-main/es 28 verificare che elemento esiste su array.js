const array = [1, 2, 3, 4, 5];
const elementoDaCercare = 3;
if (array.includes(elementoDaCercare)) {
    console.log("L'elemento esiste nell'array.");
} else {
    console.log("L'elemento non esiste nell'array.");
}
