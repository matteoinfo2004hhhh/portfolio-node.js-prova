const array = [1, 2, 3, 4, 5];
array.pop();
console.log("Array dopo la rimozione dell'ultimo elemento: " + array);
