let numero = 10;
numero++;
console.log("Il numero incrementato è: " + numero);
