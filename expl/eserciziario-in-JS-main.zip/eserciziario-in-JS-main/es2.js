let numero = 10;
const piGreco = 3.14;
let nome = "Mario";
console.log(numero);
console.log(piGreco);
console.log(nome);
