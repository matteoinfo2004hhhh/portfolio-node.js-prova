const array = [1, 2, 3, 4];
array.push(5);
console.log("Array dopo l'aggiunta alla fine: " + array);
