const persona = {
    nome: "Mario",
    cognome: "Rossi",
    età: 30,
    città: "Milano"
};
console.log(persona);
