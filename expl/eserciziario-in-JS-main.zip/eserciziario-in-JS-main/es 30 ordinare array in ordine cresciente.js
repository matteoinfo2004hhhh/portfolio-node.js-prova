const array = [5, 2, 9, 1, 5, 6];
const arrayOrdinato = array.sort((a, b) => a - b);
console.log("Array ordinato in ordine crescente: " + arrayOrdinato);
