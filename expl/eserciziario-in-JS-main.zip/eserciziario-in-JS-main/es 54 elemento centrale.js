function elementoCentrale(array) {
    const indiceCentrale = Math.floor(array.length / 2);
    return array[indiceCentrale];
}

console.log(elementoCentrale([1, 2, 3, 4, 5])); 
