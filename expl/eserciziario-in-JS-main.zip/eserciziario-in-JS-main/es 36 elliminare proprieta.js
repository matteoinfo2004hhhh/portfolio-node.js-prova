const persona = {
    nome: "Andrea",
    cognome: "Verdi",
    età: 45,
    città: "Torino"
};
delete persona.età;
console.log(persona);
