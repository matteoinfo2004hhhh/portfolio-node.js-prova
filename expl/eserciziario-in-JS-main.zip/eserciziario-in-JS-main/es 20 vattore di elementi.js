const arrayMisto = [3, "ciao", true, null, undefined];
console.log("Array con elementi di diversi tipi di dati: " + arrayMisto);
