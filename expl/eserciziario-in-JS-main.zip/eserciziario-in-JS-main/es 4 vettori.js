let numeri = [1, 2, 3, 4, 5];
let primoNumero = numeri[0];
numeri.push(6); 
numeri.pop(); 
let lunghezzaArray = numeri.length;
console.log(numeri);
console.log(primoNumero);
console.log(lunghezzaArray);
