const stringa1 = "hello";
const stringa2 = "hello";
if (stringa1 === stringa2) {
    console.log("Le stringhe sono uguali.");
} else {
    console.log("Le stringhe sono diverse.");
}
