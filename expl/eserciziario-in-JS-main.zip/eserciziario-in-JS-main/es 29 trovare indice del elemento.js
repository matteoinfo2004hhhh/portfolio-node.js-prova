const array = [10, 20, 30, 40, 50];
const elementoDaCercare = 30;
const indice = array.indexOf(elementoDaCercare);
console.log("L'elemento si trova all'indice: " + indice);
