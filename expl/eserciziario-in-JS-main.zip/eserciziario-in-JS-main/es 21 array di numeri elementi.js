const array = [5, 10, 15, 20, 25];
const elemento = array[2];
console.log("L'elemento alla posizione 2 è: " + elemento);
