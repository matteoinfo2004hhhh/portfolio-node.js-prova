const numero1 = 15;
const numero2 = 23;
const massimo = Math.max(numero1, numero2);
console.log("Il numero più grande è: " + massimo);
