let base = 8;
let altezza = 12;
let area = base * altezza;
console.log("L'area del rettangolo è: " + area);
