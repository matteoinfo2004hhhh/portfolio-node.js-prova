const numero = -7;
if (numero > 0) {
    console.log(numero + " è un numero positivo.");
} else if (numero < 0) {
    console.log(numero + " è un numero negativo.");
} else {
    console.log(numero + " è zero.");
}
