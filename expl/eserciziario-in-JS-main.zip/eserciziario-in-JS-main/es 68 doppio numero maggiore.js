function doppioMaggioreDiDieci(numero) {
    return (numero > 10) ? numero * 2 : numero;
}

console.log(doppioMaggioreDiDieci(8));
console.log(doppioMaggioreDiDieci(12)); 
