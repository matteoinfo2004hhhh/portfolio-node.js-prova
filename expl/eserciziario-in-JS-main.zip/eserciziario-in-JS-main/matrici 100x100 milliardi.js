
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);
var matrice = [];

for (var i = 0; i < 10; i++) {
    matrice[i] = [];
    for (var j = 0; j < 10; j++) {
        matrice[i][j] = Math.floor(Math.random() * 100) + 1; // Numeri casuali 
    }
}

console.log(matrice);