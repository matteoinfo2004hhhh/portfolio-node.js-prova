const stringa = "JavaScript è un linguaggio di programmazione";
const inizio = 11;
const lunghezza = 11;
const sottostringa = stringa.substr(inizio, lunghezza);
console.log("La sottosezione della stringa è: " + sottostringa);
