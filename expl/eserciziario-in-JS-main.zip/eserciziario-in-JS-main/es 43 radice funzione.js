function radiceQuadrata(numero) {
    return Math.sqrt(numero);
}

console.log("La radice quadrata è: " + radiceQuadrata(25));
