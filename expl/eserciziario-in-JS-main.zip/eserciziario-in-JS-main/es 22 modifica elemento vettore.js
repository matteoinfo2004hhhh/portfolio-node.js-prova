const array = [2, 4, 6, 8, 10];
array[1] = 12;
console.log("Array dopo la modifica: " + array);
