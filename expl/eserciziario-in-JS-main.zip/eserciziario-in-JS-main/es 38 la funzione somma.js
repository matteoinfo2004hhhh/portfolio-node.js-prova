function sommaNumeri(a, b) {
    return a + b;
}

console.log("La somma è: " + sommaNumeri(3, 7));
