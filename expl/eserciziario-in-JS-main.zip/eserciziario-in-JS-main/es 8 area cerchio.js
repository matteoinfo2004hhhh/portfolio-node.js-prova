const raggio = 5;
const areaCerchio = Math.PI * raggio * raggio;
console.log("L'area del cerchio è: " + areaCerchio);
