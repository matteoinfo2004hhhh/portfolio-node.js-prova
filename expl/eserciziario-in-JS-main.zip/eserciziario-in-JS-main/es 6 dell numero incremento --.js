let numero = 15;
numero--;
console.log("Il numero decrementato è: " + numero);
