const stringa = "Hello, World!";
const lunghezzaStringa = stringa.length;
console.log("La lunghezza della stringa è: " + lunghezzaStringa);
