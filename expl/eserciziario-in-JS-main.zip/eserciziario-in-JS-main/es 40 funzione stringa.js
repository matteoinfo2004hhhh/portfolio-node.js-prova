function lunghezzaStringa(stringa) {
    return stringa.length;
}

console.log("La lunghezza della stringa è: " + lunghezzaStringa("Hello, World!"));
