function elementoPiuPiccolo(array) {
    return Math.min(...array);
}

console.log(elementoPiuPiccolo([7, 2, 10, 4, 1]));
