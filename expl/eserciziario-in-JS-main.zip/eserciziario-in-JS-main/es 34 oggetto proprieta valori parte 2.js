const persona = {
    nome: "Maria",
    cognome: "Verdi",
    età: 25,
    città: "Roma"
};
console.log("Il nome della persona è: " + persona.nome);
console.log("Il cognome della persona è: " + persona.cognome);
console.log("Il eta della persona è: " + persona.età);