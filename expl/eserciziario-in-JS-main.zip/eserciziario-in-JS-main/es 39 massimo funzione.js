function trovaMassimo(num1, num2, num3) {
    return Math.max(num1, num2, num3);
}

console.log("Il numero più grande è: " + trovaMassimo(15, 8, 23));
