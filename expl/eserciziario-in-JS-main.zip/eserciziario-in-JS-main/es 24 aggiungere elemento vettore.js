const array = [2, 3, 4, 5];
array.unshift(1);
console.log("Array dopo l'aggiunta all'inizio: " + array);
