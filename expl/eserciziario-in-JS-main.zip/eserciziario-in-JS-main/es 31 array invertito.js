const array = [1, 2, 3, 4, 5];
const arrayInvertito = array.reverse();
console.log("Array invertito: " + arrayInvertito);
