const stringaNumero = "42";
const numeroDaStringa = parseInt(stringaNumero);
console.log("La stringa convertita in numero è: " + numeroDaStringa);
