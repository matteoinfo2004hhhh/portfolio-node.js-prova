const numero1 = 8;
const numero2 = 3;
const minimo = Math.min(numero1, numero2);
console.log("Il numero più piccolo è: " + minimo);
