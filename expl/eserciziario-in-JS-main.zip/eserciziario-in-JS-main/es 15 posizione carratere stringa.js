const stringa = "JavaScript";
const posizione = 3;
const carattere = stringa.charAt(posizione);
console.log("Il carattere alla posizione " + posizione + " è: " + carattere);
