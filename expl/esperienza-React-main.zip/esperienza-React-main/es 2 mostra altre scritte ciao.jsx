import React from 'react';

export function App(props) {
  return (
    <div className='App'>
      <h1>Ciao React.</h1>
      <h2>si inizia a prorgammare</h2>
    </div>
  );
}

// Log to console
console.log('Ciao modno')